This folder contains third party library.
